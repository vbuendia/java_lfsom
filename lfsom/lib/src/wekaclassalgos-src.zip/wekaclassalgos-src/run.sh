#!/bin/sh
java -cp lib/weka.jar:wekaclassalgos.jar -Xmx512m weka.gui.GUIChooser
